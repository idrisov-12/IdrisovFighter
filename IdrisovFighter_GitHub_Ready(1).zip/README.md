# Idrisov Fighter

Простая 2D-игра на Unity. Этот проект готов для сборки в APK через Unity Cloud Build.

## Как собрать APK
1. Загрузите этот репозиторий в Unity Cloud Build.
2. Выберите платформу Android.
3. Нажмите "Build".
